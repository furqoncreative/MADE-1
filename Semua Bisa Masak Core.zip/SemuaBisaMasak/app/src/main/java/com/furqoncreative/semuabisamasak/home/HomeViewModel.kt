package com.furqoncreative.semuabisamasak.home

import android.arch.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.furqoncreative.core.domain.usecase.recipes.RecipesUseCase

class HomeViewModel(recipesUseCase: RecipesUseCase) : ViewModel() {
    val recipes = recipesUseCase.getAllRecipes().asLiveData()
}

