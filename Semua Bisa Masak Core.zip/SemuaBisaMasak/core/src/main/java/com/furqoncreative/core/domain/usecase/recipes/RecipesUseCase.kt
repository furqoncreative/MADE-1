package com.furqoncreative.core.domain.usecase.recipes

import com.dicoding.tourismapp.core.data.Resource
import com.furqoncreative.core.domain.model.recipes.Recipes
import kotlinx.coroutines.flow.Flow

interface RecipesUseCase {
    fun getAllRecipes(): Flow<Resource<List<Recipes>>>
    fun getFavoriteRecipes(): Flow<List<Recipes>>
    fun setFavoriteRecipes(recipes: Recipes, state: Boolean)
}