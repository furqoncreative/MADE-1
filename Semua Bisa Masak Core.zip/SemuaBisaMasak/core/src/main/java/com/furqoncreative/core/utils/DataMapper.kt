package com.furqoncreative.core.utils

import com.furqoncreative.core.data.source.local.entity.recipes.RecipesEntity
import com.furqoncreative.core.data.source.remote.response.recipeslist.RecipesListItem
import com.furqoncreative.core.domain.model.recipes.Recipes


object DataMapper {
    fun mapRecipesResponsesToEntities(input: List<RecipesListItem>): List<RecipesEntity> {
        val recipesList = ArrayList<RecipesEntity>()
        input.map {
            val recipes = RecipesEntity(
                times = it.times,
                thumb = it.thumb,
                portion = it.portion,
                title = it.title,
                key = it.key,
                dificulty = it.dificulty,
                isFavorite = false
            )
            recipesList.add(recipes)
        }
        return recipesList
    }

    fun mapRecipesEntityToDomain(input: List<RecipesEntity>): List<Recipes> =
        input.map {
            Recipes(
                times = it.times,
                thumb = it.thumb,
                portion = it.portion,
                title = it.title,
                key = it.key,
                dificulty = it.dificulty,
                isFavorite = false
            )
        }

    fun mapRecipesDomainToEntity(input: Recipes) = RecipesEntity(
        times = input.times,
        thumb = input.thumb,
        portion = input.portion,
        title = input.title,
        key = input.key,
        dificulty = input.dificulty,
        isFavorite = false
    )
}