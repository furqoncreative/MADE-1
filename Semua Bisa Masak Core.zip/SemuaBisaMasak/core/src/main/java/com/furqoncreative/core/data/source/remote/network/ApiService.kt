package com.furqoncreative.core.data.source.remote.network

import com.furqoncreative.core.data.source.remote.response.recipedetail.RecipeDetailResponse
import com.furqoncreative.core.data.source.remote.response.recipesbycategory.RecipesByCategoryResponse
import com.furqoncreative.core.data.source.remote.response.recipeslist.RecipesListResponse
import com.furqoncreative.core.data.source.remote.response.recipesbysearch.RecipesBySearchResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("recipes")
    fun getAllRecipes(): RecipesListResponse

    @GET("recipe/{key}")
    fun getRecipe(@Path("key") key: String): RecipeDetailResponse

    @GET("categorys/recipes")
    fun getAllRecipesCategory(): RecipesByCategoryResponse

    @GET("search")
    fun getAllRecipesBySearch(@Query("q") q: String): RecipesBySearchResponse

    @GET("categorys/recipes/{key}")
    fun getAllRecipesByCategory(@Path("key") key: String): RecipesByCategoryResponse
}
