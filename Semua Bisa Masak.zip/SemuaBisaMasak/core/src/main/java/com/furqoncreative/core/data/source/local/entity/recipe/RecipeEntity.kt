package com.furqoncreative.core.data.source.local.entity.recipe

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "recipe")
data class RecipeEntity(

    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "id")
    var id: Int,

    @ColumnInfo(name = "servings")
    val servings: String? = null,

    @ColumnInfo(name = "times")
    val times: String? = null,

    @ColumnInfo(name = "ingredient")
    val ingredient: List<String?>? = null,

    @ColumnInfo(name = "thumb")
    val thumb: String? = null,

    @ColumnInfo(name = "step")
    val step: List<String?>? = null,

    @ColumnInfo(name = "title")
    val title: String? = null,

    @ColumnInfo(name = "dificulty")
    val dificulty: String? = null,

    @field:SerializedName("desc")
    val desc: String? = null
)