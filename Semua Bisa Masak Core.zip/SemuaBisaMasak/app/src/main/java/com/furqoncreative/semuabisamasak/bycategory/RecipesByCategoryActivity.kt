package com.furqoncreative.semuabisamasak.bycategory

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.furqoncreative.semuabisamasak.R

class RecipesByCategoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipes_by_category)
    }
}