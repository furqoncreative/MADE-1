package com.furqoncreative.core.domain.model.recipe

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class Recipe(
    var id: Int,
    val servings: String? = null,
    val times: String? = null,
    val ingredient: List<String?>? = null,
    val thumb: String? = null,
    val step: List<String?>? = null,
    val title: String? = null,
    val dificulty: String? = null,
    val desc: String? = null
) : Parcelable