package com.furqoncreative.semuabisamasak.bysearch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.furqoncreative.semuabisamasak.R

class RecipesBySearchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipes_by_search)
    }
}