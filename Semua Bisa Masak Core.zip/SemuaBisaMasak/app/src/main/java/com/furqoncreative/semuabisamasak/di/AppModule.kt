package com.furqoncreative.semuabisamasak.di

import com.furqoncreative.core.domain.usecase.recipes.RecipesInteractor
import com.furqoncreative.core.domain.usecase.recipes.RecipesUseCase
import com.furqoncreative.semuabisamasak.home.HomeViewModel

import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val useCaseModule = module {
    factory<RecipesUseCase> { RecipesInteractor(get()) }
}

val viewModelModule = module {
    viewModel { HomeViewModel(get()) }
}