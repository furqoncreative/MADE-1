package com.furqoncreative.semuabisamasak.home

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.furqoncreative.semuabisamasak.R
import com.furqoncreative.semuabisamasak.databinding.ActivityHomeBinding
import org.koin.android.viewmodel.ext.android.viewModel


class HomeActivity : AppCompatActivity() {
    private val homeViewModel: HomeViewModel by viewModel()

    private var _binding: ActivityHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_home)
        supportActionBar?.hide()

    }
}